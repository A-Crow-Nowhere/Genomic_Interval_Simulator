#!/usr/bin/env bash
set -euo pipefail

HERE="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
VENV="${HERE}/.venv"

if [[ ! -d "$VENV" ]]; then
  python3 -m venv "$VENV"
  source "$VENV/bin/activate"
  pip install --upgrade pip
  pip install -r "${HERE}/requirements.txt"
else
  source "$VENV/bin/activate"
fi

python "${HERE}/cnv_sim.py" "$@"

echo "Done. Outputs in the directory passed with --outdir (default: cnv_sim_run)."
