#!/usr/bin/env python3
# (same CNV Region Simulator CLI as previously described)

import argparse, os, random
import numpy as np
import pandas as pd

def read_chrom_sizes(path, chrom_name):
    size = None
    with open(path) as fh:
        for line in fh:
            if not line.strip():
                continue
            a = line.strip().split()
            if len(a) < 2:
                continue
            c, L = a[0], int(a[1])
            if c == chrom_name:
                size = L
                break
    if size is None:
        raise SystemExit(f"Chromosome '{chrom_name}' not found in chrom sizes file: {path}")
    return size

def sample_size(min_bp, max_bp):
    lo, hi = np.log10(min_bp), np.log10(max_bp)
    return int(round(10 ** np.random.uniform(lo, hi)))

def bounded_rand_start(chrom_length, length):
    return random.randint(1, max(1, chrom_length - length))

def choose_cells_from_freq(true_freq, total_cells, rng):
    n = max(1, int(round(true_freq * total_cells)))
    return sorted(rng.sample(range(1, total_cells + 1), n))

def frac_from_variance(v):
    v = max(1, min(100, int(v)))
    f = (v - 1) / 99.0
    return {"pos_shift_frac": f * 0.30, "size_shift_frac": f * 0.70}

def jitter_interval(start, end, chrom_length, fracs, rng):
    L = end - start
    max_shift = max(0, int(L * fracs["pos_shift_frac"]))
    shift = rng.randint(-max_shift, max_shift) if max_shift > 0 else 0
    s = start + shift
    e = end + shift
    max_delta = max(0, int(L * fracs["size_shift_frac"]))
    size_delta = rng.randint(-max_delta, max_delta) if max_delta > 0 else 0
    center = (s + e) // 2
    new_len = max(1, (e - s) + size_delta)
    s2 = max(1, center - new_len // 2)
    e2 = min(chrom_length - 1, s2 + new_len)
    if e2 <= s2:
        e2 = min(chrom_length - 1, s2 + 1)
    return s2, e2

def place_interval_overlapping_region(center, radius, chrom_length, length, rng):
    region_start = max(1, center - radius)
    region_end = min(chrom_length - 1, center + radius)
    overlap_point = rng.randint(region_start, region_end)
    half = length // 2
    s = max(1, overlap_point - half)
    e = s + length
    if e > chrom_length - 1:
        e = chrom_length - 1
        s = max(1, e - length)
    if e < region_start:
        s = region_start - length // 2
        e = s + length
    if s > region_end:
        s = region_end - length // 2
        e = s + length
    s = max(1, s); e = min(chrom_length - 1, e)
    if e <= s:
        e = min(chrom_length - 1, s + 1)
    return s, e

def main():
    ap = argparse.ArgumentParser(description="CNV Region Simulator (BED outputs)")
    ap.add_argument("--chrom-sizes", required=True, help="Two-column file: chrom length")
    ap.add_argument("--chrom", default="chr1", help="Chromosome name present in chrom-sizes (default: chr1)")
    ap.add_argument("--n-cells", type=int, default=100, help="Number of cells to simulate")
    ap.add_argument("--n-clonal", type=int, default=15, help="Number of canonical clonal CNVs")
    ap.add_argument("--n-subclonal", type=int, default=25, help="Number of canonical subclonal CNVs")
    ap.add_argument("--min-size", type=int, default=50000, help="Min CNV size (bp)")
    ap.add_argument("--max-size", type=int, default=5000000, help="Max CNV size (bp)")
    ap.add_argument("--p-geom", type=float, default=0.45, help="Geometric decay for subclonal presence (higher -> more single-cell events)")
    ap.add_argument("--max-subclonal-cells", type=int, default=10, help="Max cells a subclonal CNV can appear in")
    ap.add_argument("--variance", type=int, default=50, help="Run-level variance 1..100 (1=no variance; 100=very high)")
    ap.add_argument("--hv-n-regions", type=int, default=2, help="Number of high-variance regions to create")
    ap.add_argument("--hv-radius", type=int, default=75000, help="+/- radius (bp) around HV center")
    ap.add_argument("--hv-min-events", type=int, default=8, help="Guarantee >= this many canonical events in at least one HV region")
    ap.add_argument("--seed", type=int, default=1337, help="Random seed")
    ap.add_argument("--outdir", default="cnv_sim_run", help="Output directory")
    args = ap.parse_args()

    rng = random.Random(args.seed)
    np.random.seed(args.seed)

    chrom_length = read_chrom_sizes(args.chrom_sizes, args.chrom)
    os.makedirs(args.outdir, exist_ok=True)
    per_cell_dir = os.path.join(args.outdir, "per_cell")
    os.makedirs(per_cell_dir, exist_ok=True)

    fracs = frac_from_variance(args.variance)

    # ----- Canonical events -----
    canonical = []

    for i in range(1, args.n_clonal + 1):
        L = sample_size(args.min_size, args.max_size)
        s = bounded_rand_start(chrom_length, L + 1)
        e = min(chrom_length - 1, s + L)
        tf = round(rng.uniform(0.80, 0.99), 3)
        canonical.append({"event_id": f"clonal_{i}", "chrom": args.chrom, "start": s, "end": e, "true_freq": tf, "type": "clonal", "hv_regions": []})

    ks = np.arange(1, args.max_subclonal_cells + 1, dtype=int)
    probs = args.p_geom * (1 - args.p_geom) ** (ks - 1)
    probs = probs / probs.sum()
    for i in range(1, args.n_subclonal + 1):
        k = int(np.random.choice(ks, p=probs))
        tf = round(k / args.n_cells, 4)
        L = sample_size(args.min_size, args.max_size)
        s = bounded_rand_start(chrom_length, L + 1)
        e = min(chrom_length - 1, s + L)
        canonical.append({"event_id": f"subclonal_{i}", "chrom": args.chrom, "start": s, "end": e, "true_freq": tf, "type": "subclonal", "hv_regions": []})

    # ----- High variance regions -----
    hv_regions = []
    for ridx in range(1, args.hv_n_regions + 1):
        center = rng.randint(args.hv_radius + 1, chrom_length - args.hv_radius - 1)
        hv_regions.append({"hv_id": f"HV{ridx}", "chrom": args.chrom, "center": center, "radius": args.hv_radius,
                           "start": max(1, center - args.hv_radius), "end": min(chrom_length - 1, center + args.hv_radius), "event_ids": []})

    hv_min = min(args.hv_min_events, len(canonical))
    target_region = hv_regions[0]
    idxs = list(range(len(canonical)))
    rng.shuffle(idxs)
    for idx in idxs[:hv_min]:
        ev = canonical[idx]
        L = ev["end"] - ev["start"]
        if rng.random() < 0.3:
            L = sample_size(args.min_size, args.max_size)
        s, e = place_interval_overlapping_region(target_region["center"], target_region["radius"], chrom_length, L, rng)
        ev["start"], ev["end"] = s, e
        if target_region["hv_id"] not in ev["hv_regions"]:
            ev["hv_regions"].append(target_region["hv_id"])
        if ev["event_id"] not in target_region["event_ids"]:
            target_region["event_ids"].append(ev["event_id"])

    for region in hv_regions[1:]:
        n_extra = rng.randint(3, 6)
        for idx in rng.sample(idxs, n_extra):
            ev = canonical[idx]
            rstart, rend = region["start"], region["end"]
            if ev["end"] < rstart or ev["start"] > rend:
                L = ev["end"] - ev["start"]
                s, e = place_interval_overlapping_region(region["center"], region["radius"], chrom_length, L, rng)
                ev["start"], ev["end"] = s, e
            if region["hv_id"] not in ev["hv_regions"]:
                ev["hv_regions"].append(region["hv_id"])
            if ev["event_id"] not in region["event_ids"]:
                region["event_ids"].append(ev["event_id"])

    # ----- Per-cell observations -----
    per_cell_rows = []
    event_observed_counts = {ev["event_id"]: 0 for ev in canonical}

    for ev in canonical:
        cells = choose_cells_from_freq(ev["true_freq"], args.n_cells, rng)
        for cid in cells:
            s2, e2 = jitter_interval(ev["start"], ev["end"], chrom_length, fracs, rng)
            name = f"{ev['event_id']}|truth:{ev['true_freq']}|var:{args.variance}"
            per_cell_rows.append({"chrom": ev["chrom"], "start": s2, "end": e2, "name": name, "score": 0, "strand": ".",
                                  "true_freq": ev["true_freq"], "type": ev["type"], "cell_id": f"cell_{cid}"})
            event_observed_counts[ev["event_id"]] += 1

    # ----- Write outputs -----
    import csv
    outdir = args.outdir
    os.makedirs(outdir, exist_ok=True)
    per_cell_dir = os.path.join(outdir, "per_cell")
    os.makedirs(per_cell_dir, exist_ok=True)

    truth_path = os.path.join(outdir, "canonical_events.bed")
    with open(truth_path, "w", newline="") as fh:
        w = csv.writer(fh, delimiter="\t")
        for ev in canonical:
            hv_str = ",".join(ev["hv_regions"]) if ev["hv_regions"] else "."
            w.writerow([ev["chrom"], ev["start"], ev["end"], ev["event_id"], 0, ".", ev["true_freq"], ev["type"], hv_str])

    master_path = os.path.join(outdir, "per_cell_cnvs.bed")
    with open(master_path, "w", newline="") as fh:
        w = csv.writer(fh, delimiter="\t")
        for r in per_cell_rows:
            w.writerow([r["chrom"], r["start"], r["end"], r["name"], 0, ".", r["true_freq"], r["type"], r["cell_id"]])

    from collections import defaultdict
    per_map = defaultdict(list)
    for r in per_cell_rows:
        per_map[r["cell_id"]].append(r)
    for cell_id, rows in per_map.items():
        with open(os.path.join(per_cell_dir, f"{cell_id}.bed"), "w", newline="") as fh:
            w = csv.writer(fh, delimiter="\t")
            for r in rows:
                w.writerow([r["chrom"], r["start"], r["end"], r["name"], 0, ".", r["true_freq"], r["type"], r["cell_id"]])

    obs_path = os.path.join(outdir, "event_observed_freqs.bed")
    with open(obs_path, "w", newline="") as fh:
        w = csv.writer(fh, delimiter="\t")
        for ev in canonical:
            obs = event_observed_counts.get(ev["event_id"], 0)
            obs_freq = round(obs / args.n_cells, 4)
            w.writerow([ev["chrom"], ev["start"], ev["end"], ev["event_id"], 0, ".", ev["true_freq"], ev["type"], obs, obs_freq])

    hv_path = os.path.join(outdir, "high_variance_regions.bed")
    with open(hv_path, "w", newline="") as fh:
        w = csv.writer(fh, delimiter="\t")
        for r in hv_regions:
            events_str = ",".join(sorted(r["event_ids"])) if r["event_ids"] else "."
            w.writerow([r["chrom"], r["start"], r["end"], r["hv_id"], 0, ".", events_str])

    print("✅ Done. Outputs written to:", outdir)

if __name__ == "__main__":
    main()
